import requests
import sys
import json

class BaiduFanyi:
    def __init__(self, query_str):
        self.lang_detect_url= "https://fanyi.baidu.com/langdetect"
        self.query_str = query_str
        self.trans_url = "https://fanyi.baidu.com/basetrans"
        self.headers = {"User-Agent": "Mozilla/5.0 (Linux; Android 5.1.1; Nexus 6 Build/LYZ28E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36"}

    def parse_url(self, url, data):#发送post请求,获取响应
        response = requests.post(url, data=data, headers= self.headers)
        return json.loads(response.content.decode())

    def get_ret(self,dict_response):#提取翻译的结果
        ret = dict_response["trans"][0]["dst"]
        print("result is :",ret)

    def run(self):
        #获取语言类型
            #1.1 准备post的url地址, post_data
        lang_detect_data = {"query":self.query_str}
            #1.2 发送post请求，获取响应
        lang = self.parse_url(self.lang_detect_url, lang_detect_data)["lan"]
        #2.准备post的数据
        trans_data = { "from": "zh","to": "en","query": self.query_str,} if lang == "zh" else { "from": "en","to": "zh","query": self.query_str,}
        #3.发送请求，获取响应
        dict_response = self.parse_url(self.trans_url,trans_data)
        #4.提取翻译结果
        self.get_ret(dict_response)

if __name__ == '__main__':
    query_str = input("请输入你要翻译的内容:")
    baidu_fanyi = BaiduFanyi(query_str)
    baidu_fanyi.run()