import re
import requests
import json

url = "https://36kr.com/"
html_str = requests.get(url)

ret = re.findall("<script>var props={.*?}</script>", html_str)
print(ret)