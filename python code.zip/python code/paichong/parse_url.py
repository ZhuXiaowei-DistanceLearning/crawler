import requests
from retrying import retry

headers = {}

def _parse_url(url,method,data,proxies):
    print("*"*20)
    if method=="POST":
        response = requests.post(url, data=data, headers=headers, proxies=proxies)
    else:
        response = requests.post(url, data=data, headers=headers, proxies=proxies)
    assert response.status_code == 200
    return response.content.decode()

def _parse_url(url,data,proxies,method='GET'):
    try:
        html_str = _parse_url(url, method, data, proxies)
    except:
        html_str = None
    return html_str

if __name__ == "__main__":
    url = "www.baidu.com"
    print(_parse_url(url))