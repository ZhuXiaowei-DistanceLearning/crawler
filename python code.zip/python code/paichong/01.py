import requests
import sys
import json

hedaers = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 5.1.1; Nexus 6 Build/LYZ28E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Mobile Safari/537.36",
    # "Cookie": "BIDUPSID=03449E18AD058C5220B31A7C575B90DA; BAIDUID=A7D31FB949AFA3096641F2574D5AA9E3:FG=1; PSTM=1528287323; BDUSS=Jqajk5SmhYTHI5Sk91Sml0dGVnNE10MkhleEJMWHhZfm90SlF-RzItbXptdHBiQVFBQUFBJCQAAAAAAAAAAAEAAAAsomw4X1hpYU9fV2VpXzUyMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALMNs1uzDbNbMn; REALTIME_TRANS_SWITCH=1; FANYI_WORD_SWITCH=1; HISTORY_SWITCH=1; SOUND_SPD_SWITCH=1; SOUND_PREFER_SWITCH=1; locale=zh; Hm_lvt_64ecd82404c51e03dc91cb9e8c025574=1539083911,1540472452,1540891955; Hm_lpvt_64ecd82404c51e03dc91cb9e8c025574=1540891955; to_lang_often=%5B%7B%22value%22%3A%22zh%22%2C%22text%22%3A%22%u4E2D%u6587%22%7D%2C%7B%22value%22%3A%22en%22%2C%22text%22%3A%22%u82F1%u8BED%22%7D%5D; from_lang_often=%5B%7B%22value%22%3A%22en%22%2C%22text%22%3A%22%u82F1%u8BED%22%7D%2C%7B%22value%22%3A%22zh%22%2C%22text%22%3A%22%u4E2D%u6587%22%7D%5D"
}
query_sring = input("请输入需要翻译的单词:")
post_data = {
    "from": "zh",
    "to": "en",
    "query": query_sring,
}

post_url = "https://fanyi.baidu.com/basetrans"

r = requests.post(post_url, data=post_data, headers=hedaers)

dict_ret = json.loads(r.content.decode())

ret = dict_ret["trans"][0]["dst"]

print("result is :", ret)
