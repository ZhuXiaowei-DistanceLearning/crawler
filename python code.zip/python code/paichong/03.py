import json
import requests


url = ""
response = requests.get(url)